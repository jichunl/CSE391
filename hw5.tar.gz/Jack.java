// This program prints some messages.
// It is really great.

public class Jack {
    public static void main(String[] args) {
        System.out.println("I am Jack's raging bile duct.");
        System.out.println("I am Jack's complete lack of surprise.");

        System.out.println("The stuff you own,");

        System.out.println("ends up owning you.");
    }
}
